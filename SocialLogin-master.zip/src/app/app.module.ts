import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { SocialLoginModule, AuthServiceConfig, LoginOpt } from "angularx-social-login";
import { GoogleLoginProvider, FacebookLoginProvider,LinkedInLoginProvider } from "angularx-social-login";
import { LoginComponent } from './login/login.component';

let config = new AuthServiceConfig([
 
  {
    id:FacebookLoginProvider.PROVIDER_ID,
    provider:new FacebookLoginProvider("472700430293998")
  },

  {
    id:GoogleLoginProvider.PROVIDER_ID,
    provider:new GoogleLoginProvider("904792640544-0dpqkj7rq8lscihqm08534bpdapmdih9.apps.googleusercontent.com")
  },

  {
    id:LinkedInLoginProvider.PROVIDER_ID,
    provider:new LinkedInLoginProvider("904792640544-0dpqkj7rq8lscihqm08534bpdapmdih9.apps.googleusercontent.com")
  }

]);



export function provideConfig() {
  return config;
}

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    SocialLoginModule
  ],
  providers: [
    {
      provide:AuthServiceConfig,
      useFactory:provideConfig
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
